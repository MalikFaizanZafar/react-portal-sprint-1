import React from 'react';

const Products = () => {
    return(
        <h2>
            Products
        </h2>
    )
}

export default Products;