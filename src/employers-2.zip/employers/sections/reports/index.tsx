import React from 'react';

const Reports = () => {
    return(
        <h2>
            Reports
        </h2>
    )
}

export default Reports;