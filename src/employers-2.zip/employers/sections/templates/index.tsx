import React from 'react';

const Templates = () => {
    return(
        <h2>
            Templates
        </h2>
    )
}

export default Templates;