import React from 'react';

const MyProfile = () => {
    return(
        <h2>
            My Profile
        </h2>
    )
}

export default MyProfile;