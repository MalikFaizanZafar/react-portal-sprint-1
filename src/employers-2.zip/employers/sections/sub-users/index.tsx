import React from 'react';

const SubUsers = () => {
    return(
        <h2>
            SubUsers
        </h2>
    )
}

export default SubUsers;